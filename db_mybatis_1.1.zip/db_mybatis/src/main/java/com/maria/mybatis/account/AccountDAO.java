package com.maria.mybatis.account;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import com.maria.mybatis.account.AccountVO;




@Mapper
public interface AccountDAO {
	
	//회원가입
	public int createAccount(AccountVO vo) throws Exception;
	
	//로그인
	public AccountVO login(AccountVO vo) throws Exception;
	
	//유저 정보 조회
	public List<AccountVO> showLogin() throws Exception;
	


}

