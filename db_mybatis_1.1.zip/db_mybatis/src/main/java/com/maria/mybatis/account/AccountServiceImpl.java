package com.maria.mybatis.account;

import java.util.List;

import javax.inject.Inject;
import com.maria.mybatis.account.AccountVO;
import org.springframework.stereotype.Service;


@Service
public class AccountServiceImpl implements AccountService {
	
	@Inject AccountDAO dao;

	@Override
	public int createAccount(AccountVO vo) throws Exception {
		
		return dao.createAccount(vo);
	}
	
	@Override
	public AccountVO login(AccountVO vo) throws Exception{
		return dao.login(vo);
	}
	
	@Override
	public List<AccountVO> showLogin() throws Exception{
		return dao.showLogin();
	}

}
