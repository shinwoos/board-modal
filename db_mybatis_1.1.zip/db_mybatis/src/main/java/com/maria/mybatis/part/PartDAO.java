package com.maria.mybatis.part;

import java.util.HashMap;
import java.util.List;

import javax.inject.Inject;
import javax.print.attribute.HashAttributeSet;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

@Repository
public class PartDAO {
	
	@Inject
	SqlSession sqlSession;
	
	// 총 조회
	public List<PartVO> partListAll(){
		return sqlSession.selectList("partMapper.partListAll");
	}
	
	//  글 추가
	public void insertPart(PartVO vo){
		sqlSession.insert("partMapper.insertPart", vo);
	}
	
	//  글 삭제
	public void deletePart(int partNo){
		sqlSession.delete("partMapper.deletePart", partNo);
	}
	//	글 수정
	public void updatePart(PartVO vo){
		sqlSession.update("partMapper.updatePart",vo);
	}
	
	// 글 상세조회
	public List<PartVO> viewPart(int partNo) {
		return sqlSession.selectList("partMapper.viewPart", partNo);	
	}
	
	//게시물 목록 + 페이징 + 키워드 검색
	public List<PartVO> searchPart(int displayPost, int postNum, String searchType, String keyword){
		HashMap<String, Object> data = new HashMap<String, Object>();
		
		data.put("displayPost", displayPost);
		data.put("postNum", postNum);
		
		data.put("searchType", searchType);
		data.put("keyword", keyword);
		
		
		return sqlSession.selectList("partMapper.searchPart", data);
	}

}
