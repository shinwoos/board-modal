package com.maria.mybatis.part;

import java.util.List;

public interface PartService {

	//전부 조회
	public List<PartVO> partListAll();
	
	// 글 추가
	public void insertPart(PartVO vo);
	
	// 글 삭제
	public void deletePart(int partNo);
	
	// 글 수정
	public void updatePart(PartVO vo);
	
	// 글 상세 조회
	public List<PartVO> viewPart(int partNo);
	
	// 게시물 목록 + 페이징 + 검색
	public List<PartVO> searchPart(int displayPost, int postNum, String searchType, String keyword);

	
}
