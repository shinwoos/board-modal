package com.maria.mybatis.part;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

@Service
public class PartServiceImpl implements PartService{
	
	@Inject
	PartDAO partDAO;
	
	@Override
	public List<PartVO> partListAll(){
		return partDAO.partListAll();
	}

	@Override
	public void insertPart(PartVO vo) {		
		partDAO.insertPart(vo);
	}

	@Override
	public void deletePart(int partNo) {
		partDAO.deletePart(partNo);	
	}

	@Override
	public void updatePart(PartVO vo) {
		partDAO.updatePart(vo);
	}

	@Override
	public List<PartVO> viewPart(int no) {
		return partDAO.viewPart(no);
	}
	
	
	
	
	

}
