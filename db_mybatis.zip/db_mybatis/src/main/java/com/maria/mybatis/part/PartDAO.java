package com.maria.mybatis.part;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

@Repository
public class PartDAO {
	
	@Inject
	SqlSession sqlSession;
	
	// 총 조회
	public List<PartVO> partListAll(){
		return sqlSession.selectList("partMapper.partListAll");
	}
	
	//  글 추가
	public void insertPart(PartVO vo){
		sqlSession.insert("partMapper.insertPart", vo);
	}
	
	//  글 삭제
	public void deletePart(int partNo){
		sqlSession.delete("partMapper.deletePart", partNo);
	}
	//	글 수정
	public void updatePart(PartVO vo){
		sqlSession.update("partMapper.updatePart",vo);
	}
	
	

}
