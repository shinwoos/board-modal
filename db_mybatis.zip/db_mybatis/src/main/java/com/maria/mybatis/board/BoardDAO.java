package com.maria.mybatis.board;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

@Repository
public class BoardDAO {
	
	@Inject
	SqlSession sqlSession;
	
	// 1.게시판 전체 조회
	public List<BoardVO> listAll(){
		return sqlSession.selectList("boardMapper.listAll");	
	}
	
	// 2.게시판 글 추가
	public void insertList(BoardVO vo) {
		sqlSession.insert("boardMapper.insertList", vo);
	}
	
	// 3.게시판 글 삭제
	public void deleteList(int no) {
		sqlSession.delete("boardMapper.deleteList", no);
	}
	
	// 4.게시판 글 수정
	public void updateList(BoardVO vo) {
		sqlSession.update("boardMapper.updateList", vo);
	}
	

}
