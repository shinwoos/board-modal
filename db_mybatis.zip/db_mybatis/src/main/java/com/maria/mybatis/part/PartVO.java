package com.maria.mybatis.part;

public class PartVO {
	
	private int partNo;
	private String phone_before;
	private String phone_after;
	private String group_name;
	private String user_name;
	private String ip;
	private String date;
	
	public int getPartNo() {
		return partNo;
	}
	public void setPartNo(int partNo) {
		this.partNo =partNo;
	}
	public String getPhone_before() {
		return phone_before; 
	}
	public void setPhone_before(String phone_before) {
		this.phone_before = phone_before;
	}
	public String getPhone_after() {
		return phone_after;
	}
	public void setPhone_after(String phone_after) {
		this.phone_after = phone_after;
	}
	public String getGroup_name() {
		return group_name;
	}
	public void setGroup_name(String group_name) {
		this.group_name = group_name;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	

}
