package com.maria.mybatis.part;

import java.util.List;

public interface PartService {

	//전부 조회
	public List<PartVO> partListAll();
	
	// 글 추가
	public void insertPart(PartVO vo);
	
	// 글 삭제
	public void deletePart(int partNo);
	
	// 글 수정
	public void updatePart(PartVO vo);
	
}
