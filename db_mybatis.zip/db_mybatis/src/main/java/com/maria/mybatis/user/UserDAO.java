package com.maria.mybatis.user;

import java.util.List;
import java.util.Map;


import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserDAO {

	@Autowired
	private SqlSession SqlSession;

	
	//사용자 목록 
	public  List<Map<String, Object>>  getUserList() throws Exception {
		return SqlSession.selectList("com.maria.mybatis.user.UserDAO.userList");
	}
	
	//사용자 총 수
	public int getTestValue() {
		return SqlSession.selectOne("com.maria.mybatis.user.UserDAO.userCount");
	}
	//사용자 목록 
	public  List<Map<String, Object>>  getUserList2() throws Exception {
		return SqlSession.selectList("com.maria.mybatis.user.UserDAO.userList2");
	}
	
	//사용자 총 수
	public int getTestValue2() {
		return SqlSession.selectOne("com.maria.mybatis.user.UserDAO.userCount2");
	}
} 