package com.maria.mybatis.board;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

@Service
public class BoardServiceImpl implements BoardService{
	
	@Inject
	BoardDAO boardDAO;

	// 1.테이블 전체조회
	@Override
	public List<BoardVO> listAll() {
		return boardDAO.listAll();
	}

	// 2.글 쓰기
	@Override
	public void insertList(BoardVO vo) {		
		boardDAO.insertList(vo);
	}

	// 3.글 삭제
	@Override
	public void deleteList(int no) {
		boardDAO.deleteList(no);
	}

	// 4.글 수정
	@Override
	public void updateList(BoardVO vo) {
		boardDAO.updateList(vo);
	}
	
	

}
