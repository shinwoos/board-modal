package com.maria.mybatis.account;

public class AccountVO {
	
	

	private String account_id; // 회원 아이디
	private String account_pw; // 회원 비밀번호
	private String account_name; // 회원 이름
	private String date;
	
	public String getAccount_id() {
		return account_id;
	}

	public void setAccount_id(String account_id) {
		this.account_id = account_id;
	}

	public String getAccount_pw() {
		return account_pw;
	}

	public void setAccount_pw(String account_pw) {
		this.account_pw = account_pw;
	}
	
	public String getAccount_name(){
		return account_name;
	}
	public void setAccount_name(String account_name){
		this.account_name = account_name;
	}
	public String getDate(){
		return date;
	}
	public void setDate(String date){
		this.date = date;
	}
	
	@Override
	public String toString() {
		return "AccountVO [Account_id=" + account_id + ", Account_pw=" + account_pw + ", Account_name=" + account_name + "]";
	}
	

}
