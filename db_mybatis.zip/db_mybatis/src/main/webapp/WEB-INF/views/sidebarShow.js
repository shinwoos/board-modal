const btn1 = document.getElementById("#btn-first");


function test(){
	alert("test");
}

btn1.addEventListener('click', test);



onclick="btn1"