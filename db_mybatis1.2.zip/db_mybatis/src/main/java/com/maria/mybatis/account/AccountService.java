package com.maria.mybatis.account;

import java.util.List;

import com.maria.mybatis.account.AccountVO;

public interface AccountService {
	
	public int createAccount(AccountVO vo) throws Exception;
	
	public AccountVO login(AccountVO vo) throws Exception;
	
	public List<AccountVO> showLogin() throws Exception;
	

}
