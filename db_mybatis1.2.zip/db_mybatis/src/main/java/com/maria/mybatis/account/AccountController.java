package com.maria.mybatis.account;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.security.auth.login.AccountException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.ui.Model;

import com.maria.mybatis.account.AccountService;
import com.maria.mybatis.account.AccountVO;
import com.maria.mybatis.board.BoardService;
import com.maria.mybatis.board.BoardVO;
import com.maria.mybatis.part.PartService;
import com.maria.mybatis.part.PartVO;
import com.maria.mybatis.user.UserService;

@Controller
@RequestMapping("/account/*")
public class AccountController {

	private static final Logger logger = LoggerFactory.getLogger(AccountController.class);

	@Inject
	BoardService boardService;
	@Inject
	AccountService service;
	@Autowired
	UserService userService;
	@Inject
	PartService partService;

	// 회원가입 get
	@RequestMapping(value = "/createAccount12", method = RequestMethod.GET)
	public String getRegister() throws Exception {
		logger.info("get register");

		return "createAccount1";
	}

	// 회원가입 post
	@RequestMapping(value = "/createAccount12", method = RequestMethod.POST)
	public String postRegister(AccountVO vo, String text, byte[] bytes) throws Exception {
		logger.info("post register");
		System.out.println(vo.getAccount_pw());
		String sha256 = "";
		
		MessageDigest md = MessageDigest.getInstance("SHA-256");
	
		md.update(vo.getAccount_pw().getBytes("UTF-8"));
		
		byte[] mdHash = md.digest();
		
		StringBuffer hexMdHash = new StringBuffer();
		
		for(byte b : mdHash){
			String hexString = String.format("%02x", b);
			hexMdHash.append(hexString);
		}
		sha256 = hexMdHash.toString();
		//password hashing
		System.out.println(sha256);
		
		vo.setAccount_pw(sha256);
		System.out.println("해싱된 암호"+ vo.getAccount_pw());
		
		service.createAccount(vo);

		return "home";
	}

	// ========================= 로그인 ==============================
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login(AccountVO vo, HttpServletRequest req, Model model, HttpSession session) throws Exception {

		
logger.info("post login");
		
		// 사용자 목록 가져오기
		List<PartVO> partListAll = partService.partListAll();

		AccountVO login = service.login(vo);

		session.setAttribute("account",vo.getAccount_id());
		System.out.println(vo.getAccount_id());
		System.out.println(vo.getAccount_pw());
		
		// 로그인 실패
		if (login == null) {
			System.out.println("로그인실패했음.");
			model.addAttribute("account", null);
			model.addAttribute("msg", false);
			
			return "home";
			
			
		// 로그인 성공
		} else {
			model.addAttribute("account", vo.getAccount_id());
			
			
			System.out.println(session.getAttribute("account"));
			// model
		
			model.addAttribute("partListAll", partListAll);
			return "frameSet";
		}
		
		
		}
		
		@RequestMapping(value = "/partList.do", method = RequestMethod.GET)
		public String loginTable(Model model) throws Exception {

			// 사용자 목록 가져오기
			List<PartVO> partListAll = partService.partListAll();
			
				model.addAttribute("partListAll", partListAll);
				return "partList";
				
			
		/*// 사용자 목록 가져오기
		List<Map<String, Object>> userList = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> userList2 = new ArrayList<Map<String, Object>>();
		List<BoardVO> listAll = boardService.listAll();
		List<AccountVO> showLogin = service.showLogin();
		List<PartVO> partListAll = partService.partListAll();

		logger.info("post login");

		AccountVO login = service.login(vo);

		System.out.println("crud 데이터 받기 성공" + listAll);
		System.out.println(vo.getAccount_id());
		System.out.println(vo.getAccount_pw());

		if (login == null) {
			model.addAttribute("account", null);
			model.addAttribute("msg", false);
			System.out.println("로그인 실패 ( if 들어옴 )");
		} else {
			session.setAttribute("account", vo.getAccount_id());
			model.addAttribute("account", vo.getAccount_id());
			System.out.println("성공 ( else 들어옴 )");
		}

		// model

		userList = userService.getUserList();
		System.out.println("userList == " + userList);
		model.addAttribute("userList", userList);

		userList2 = userService.getUserList2();
		System.out.println("userList2 == " + userList2);
		model.addAttribute("userList2", userList2);

		model.addAttribute("listAll", listAll);

		model.addAttribute("showLogin", showLogin);

		model.addAttribute("partListAll", partListAll);

		return "loginResult";*/
	}

	// ========================= 로그아웃 ====================
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpSession session) throws Exception {
		System.out.println("로그아웃");
		session.invalidate();

		return "home";
	}

	/*
	 * //01. 게시판 전체 조회
	 * 
	 * @RequestMapping(value= "/login" ,method = RequestMethod.GET) public String
	 * selectList(Model model) { List<BoardVO> selectList =
	 * boardService.selectList();
	 * 
	 * System.out.println(selectList);
	 * 
	 * //model model.addAttribute("selectList", selectList);
	 * 
	 * return null; }
	 */

	// ===================== 파트 게시글 작성 =====================
	@RequestMapping(value = "/insertPart.do", method = RequestMethod.POST)
	public @ResponseBody String insertPart(@RequestParam Map<String, Object> map) {

		
		System.out.println("데이터 받고있습니다."+map);
		System.out.println("#######"+map+"#######");
		
		
		PartVO vo = new PartVO();

		vo.setPhone_before(map.get("before").toString());
		vo.setPhone_after(map.get("after").toString());
		vo.setGroup_name(map.get("group").toString());
		vo.setUser_name(map.get("user").toString());
		vo.setIp(map.get("ip").toString());
		
/*		System.out.println("#####################");
		System.out.println(vo.getPhone_before()+vo.getPhone_after()+vo.getGroup_name()+vo.getUser_name()+vo.getIp());
		System.out.println("#####################");
*/
		partService.insertPart(vo);

		return "{}";
	}
 
	// ===================== 파트 게시글 삭제 =====================
	@RequestMapping(value = "/deletePart.do", method = RequestMethod.GET)
	public @ResponseBody String deleteList(@RequestParam Map<String, Object> map) {

		int partNo = Integer.parseInt(map.get("no").toString());

		System.out.println("삭제에요삭제에요삭제에요삭제" + partNo); 
		partService.deletePart(partNo);
		 
		return "{}";
	}

	//  ===================== 파트 게시글 수정 =====================

	@RequestMapping(value = "/updatePart.do", method = RequestMethod.POST)
	public @ResponseBody String updatePart(@RequestParam Map<String, Object> map) {

		System.out.println(map);

		PartVO vo = new PartVO();

		vo.setPhone_before(map.get("before").toString());
		vo.setPhone_after(map.get("after").toString());
		vo.setGroup_name(map.get("group").toString());
		vo.setUser_name(map.get("user").toString());
		vo.setIp(map.get("ip").toString());
		vo.setPartNo(Integer.parseInt(map.get("no").toString()));

		partService.updatePart(vo);

		return "{}";

	}
	
	//=======================키워드 상세 조회 =============================
	@RequestMapping(value = "/searchPart.do", method= RequestMethod.GET)
	public @ResponseBody List<PartVO> getSearchPart(@RequestParam Map<String, Object> map){
		
		
		
		/* List<PartVO> partListAll = partService.searchPart(); */
		
		Map<String, Object> m = new HashMap<String, Object>();
		
		
		System.out.println(map);
	
		String searchType = map.get("type").toString();
		System.out.println("=================================");
		System.out.println(searchType);
		System.out.println("=================================");
		
		if(searchType.equals("name")) {
			
			m.put("user_name", map.get("input"));
			System.out.println("유저이름"+m);
			
		}if(searchType.equals("group")) {
			
			m.put("group_name", map.get("input"));
			System.out.println("그룹"+m);
						
		} if(searchType.equals("no")) {
			
			m.put("partNo", map.get("input"));
			System.out.println("!~~1~번호"+m);
		}
		
		List<PartVO> searchPart = partService.searchPart(m);
		return searchPart;
	}
	// ===================== 파트 게시글 상세조회 ======================

	@RequestMapping(value = "/viewPart.do", method = RequestMethod.POST)
	public @ResponseBody List<PartVO> viewPart(@RequestParam Map<String, Object> map) {
		
		
		System.out.println("=================================");
		System.out.println("글123123 번호 검색 데이터 받기 테스트: " + map);
		System.out.println("=================================");
		
		int partNo = Integer.parseInt(map.get("no").toString());
		
		System.out.println(partNo);
		
		List<PartVO> partListAll = partService.viewPart(partNo);
		
		
		System.out.println(partListAll.get(0).getPhone_before());
		System.out.println(partListAll.get(0).getPhone_after());
		System.out.println(partListAll.get(0).getGroup_name());
		System.out.println(partListAll.get(0).getIp());
		System.out.println(partListAll.get(0).getUser_name());

		//model.addAttribute("partListAll", partListAll);
		
		
		return partListAll;
	}


	@RequestMapping(value = "/insertList.do", method = RequestMethod.POST)
	public String insertList(@RequestParam Map<String, Object> map) {

		System.out.println(map);
		System.out.println(map.get("title").toString());
		System.out.println(map.get("contents").toString());

		BoardVO vo = new BoardVO();

		vo.setTitle(map.get("title").toString());
		vo.setContents(map.get("contents").toString());

		System.out.println(vo.getTitle() + vo.getContents());

		boardService.insertList(vo);

		return "redirect:/login";
	}
	
	//====================== 사용자 관리 페이지 조회 =======================
	@RequestMapping(value = "/selectList.do")
	public String showLogin(Model model) throws Exception{
		
		System.out.println("request test");
		System.out.println("빌드 됨.");
		List<AccountVO> showLogin = service.showLogin();
			
		model.addAttribute("showLogin", showLogin);
		
		return "userTable";
		
		
	}
	
	//===================== 프레임 셋 ===============================
	@RequestMapping(value= "/frameSet.do")
	public String frameSet(String test){
		
		return "frameSet";
	}
	
	@RequestMapping(value= "/nav.do")
	public String navBar(String test){
		System.out.println("nav request test");
		return "nav";
	}
	
	@RequestMapping(value = "sideBar.do")
	public String sideBar(String test){
		System.out.println("side request test");
		return "sideBar";
	}
	

	

}
