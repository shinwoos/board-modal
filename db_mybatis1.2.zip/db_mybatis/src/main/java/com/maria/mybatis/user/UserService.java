package com.maria.mybatis.user;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
@Repository
public class UserService {

	@Autowired
	UserDAO userDAO;
	
	//사용자 목록 가져오기 
	public List<Map<String, Object>> getUserList() {
		List<Map<String, Object>> userList = new ArrayList<Map<String, Object>>();
		
		try {
			userList = userDAO.getUserList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return userList;
	}
	
	//사용자 총 수
	 public int getTestValue(){
         return userDAO.getTestValue();
   }
	 
		//사용자 목록 가져오기 
		public List<Map<String, Object>> getUserList2() {
			List<Map<String, Object>> userList2 = new ArrayList<Map<String, Object>>();
			
			try {
				userList2 = userDAO.getUserList2();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			return userList2;
		}
		
		//사용자 총 수
		 public int getTestValue2(){
	         return userDAO.getTestValue2();
	   }

}
