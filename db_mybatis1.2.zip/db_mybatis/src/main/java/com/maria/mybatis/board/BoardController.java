/*package com.maria.mybatis.board;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class BoardController {
	
	@Inject
	BoardService boardService;
	
	//01. 게시판 전체 조회
	 @RequestMapping(value= "/list.do" ,method = RequestMethod.GET) 
	public String listAll(Model model) {
		List<BoardVO> listAll = boardService.listAll();
		
		System.out.println(listAll);
		
		//model
		model.addAttribute("listAll", listAll);
		return "main";
	}
	 
	 @RequestMapping(value= "/insertList.do", method = RequestMethod.POST)
	public String insertList(@RequestParam Map<String, Object> map) {

		System.out.println(map);
		System.out.println(map.get("title").toString());
		System.out.println(map.get("contents").toString());
		
		BoardVO vo = new BoardVO();
		
		vo.setTitle(map.get("title").toString());
		vo.setContents(map.get("contents").toString());
		
		System.out.println(vo.getTitle() + vo.getContents());
		
		boardService.insertList(vo);
		
		return "redirect:/list.do";
	}
	
	

}
*/