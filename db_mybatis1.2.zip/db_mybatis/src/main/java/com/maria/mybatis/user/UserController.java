package com.maria.mybatis.user;

import javax.servlet.http.HttpServletRequest;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;



@Controller
public class UserController {

	@Autowired
	UserService userService;

	@RequestMapping(value = "/user3", method = RequestMethod.GET)
	public String Model(Model model, HttpServletRequest request, UserVO userVO) {

		//사용자 목록 가져오기 
		List<Map<String, Object>> userList = new ArrayList<Map<String, Object>>();
		
		//사용자 총 수 
		int result = 0;

		
		userList = userService.getUserList();
		result = userService.getTestValue();
		
		System.out.println("userList == "+userList);
		System.out.println("result == "+result);
		
		model.addAttribute("userList", userList);
		model.addAttribute("userCount", result);
		
		return "user";

	}
	
	@RequestMapping(value = "/user4", method = RequestMethod.GET)
	public String Model2(Model model, HttpServletRequest request, UserVO userVO) {

		//사용자 목록 가져오기 
		List<Map<String, Object>> userList2 = new ArrayList<Map<String, Object>>();
		
		//사용자 총 수 
		int result2 = 0;

		
		userList2 = userService.getUserList2();
		result2 = userService.getTestValue2();
		
		System.out.println("userList2 == "+userList2);
		System.out.println("result2 == "+result2);
		
		model.addAttribute("userList2", userList2);
		model.addAttribute("userCount2", result2);
		
		return "userTwo";

	}
	
}
	