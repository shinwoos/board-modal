package com.maria.mybatis.account;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.maria.mybatis.account.AccountVO;

@Repository
public class AccountDAOImpl implements AccountDAO {
	
	
	@Inject SqlSession sql;
	//회원 가입

	@Override
	public int createAccount(AccountVO vo) throws Exception {
		return sql.insert("accountMapper.createAccount", vo);
		
	}
	
	//로그인
	@Override
	public AccountVO login(AccountVO vo) throws Exception{
		return sql.selectOne("accountMapper.login", vo);
	}
	
	//유저 정보 조회
	public List<AccountVO> showLogin() throws Exception{
		return sql.selectList("accountMapper.showLogin");
		
	}

}
